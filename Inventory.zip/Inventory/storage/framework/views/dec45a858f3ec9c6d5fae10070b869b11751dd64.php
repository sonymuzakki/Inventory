<header id="page-topbar">
    <div class="navbar-header">
        <div class="d-flex">
            <!-- LOGO -->
            <div class="navbar-brand-box">
                

                <a href="/dashboard" class="logo logo-light">
                    <span class="logo-sm">
                        <img src="logo/favicon.png"  alt="logo-sm-light" height="75">
                    </span>
                    <span class="logo-lg">
                        <img src="logo/favicon.png"  alt="logo-light" height="75">
                    </span>
                </a>
            </div>

            

            <!-- App Search-->
            

            
        </div>

        <div class="d-flex">

            

            

            

            

            

            <div class="dropdown d-inline-block user-dropdown">
                <button type="button" class="btn header-item waves-effect" id="page-header-user-dropdown"
                    data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <img class="rounded-circle header-profile-user ri-account-circle-fill" src="assets/images/users/avatar-1.jpg" alt="Header Avatar" <h5>  <?php echo e(Auth::user()->name); ?></h5>
                    
                    <span class="d-none d-xl-inline-block ms-1">
                    <i class="mdi mdi-chevron-down d-none d-xl-inline-block"></i>

                </button>
                <div class="dropdown-menu dropdown-menu-end">
                    <!-- item-->
                    <a class="dropdown-item" href="<?php echo e(route('admin.profile')); ?>"><i class="ri-user-line align-middle me-1"></i> Profile</a>
                    <a class="dropdown-item" href="#"><i class="ri-lock-unlock-line align-middle me-1"></i> Lock screen</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item text-danger" href="<?php echo e(route('admin.logout')); ?>"><i class="ri-shut-down-line align-middle me-1 text-danger"></i> Logout</a>
                </div>
            </div>

            

        </div>
    </div>
</header>
<?php /**PATH D:\Project\Inventory\resources\views/admin/body/header.blade.php ENDPATH**/ ?>