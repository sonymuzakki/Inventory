<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>document.write(new Date().getFullYear())</script> © ITSD.
            </div>
            
        </div>
    </div>
</footer>
<?php /**PATH D:\Project\Inventory\resources\views/admin/body/footer.blade.php ENDPATH**/ ?>