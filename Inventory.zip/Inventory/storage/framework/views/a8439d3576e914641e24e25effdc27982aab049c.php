<div class="vertical-menu">

    <div data-simplebar class="h-100">

        <!-- User details -->
        

        <!--- Sidemenu -->
        <div id="sidebar-menu">


            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title">Menu</li>

                <li>
                    <a href="/dashboard" class="waves-effect">
                        <i class="ri-dashboard-line"></i><span class="badge rounded-pill bg-success float-end"></span>
                        <span>Dashboard</span>
                    </a>
                </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="ri-layout-3-line"></i>
                        <span>Manage Inventory</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(route('invetaris.all')); ?>">Data Inventory</a></li>
                        <li><a href="<?php echo e(route('invetaris.add')); ?>">Form Inventory</a></li>
                        
                    </ul>
                </li>

                


                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="ri-layout-3-line"></i>
                        <span>Manage Master</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(route('divisi.all')); ?>">Divisi</a></li>
                        <li><a href="<?php echo e(route('lokasi.all')); ?>">Lokasi</a></li>
                        <li><a href="<?php echo e(route('jenis.all')); ?>">Jenis</a></li>
                        
                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="ri-layout-3-line"></i>
                        <span>Manage Request</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(route('request.all')); ?>">Request All Support</a></li>
                        <li><a href="<?php echo e(route('request.pending')); ?>">Request Proses</a></li>
                        
                    </ul>
                </li>

                

                <li class="menu-title">Pages</li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="ri-account-circle-line"></i>
                        <span>Profile</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(route('admin.profile')); ?>">Profile</a></li>
                        <li><a href="<?php echo e(route('edit.profile')); ?>">Edit Profile</a></li>
                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="ri-profile-line"></i>
                        <span>Support</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        
                        <li><a href="<?php echo e(route('request.add')); ?>">Form Request Support</a></li>

                    </ul>
                </li>

            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div>
<?php /**PATH D:\Project\Inventory\resources\views/admin/body/sidebar.blade.php ENDPATH**/ ?>